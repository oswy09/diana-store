import{u}from"./BLVGJyOD.js";const l=()=>({sendToWhatsApp:(o,n,t)=>{const i=u();let e=`*Nuevo Pedido - Di Store*

`;e+=`*Cliente:* ${o.name}
`,e+=`*Teléfono:* ${o.phone}
`,o.email&&(e+=`*Email:* ${o.email}
`),o.city&&(e+=`*Ciudad:* ${o.city}
`),o.address&&(e+=`*Dirección:* ${o.address}
`),e+=`*Forma de Pago:* ${o.paymentMethod==="1_cuota"?"1 Cuota":"2 Cuotas"}

`,e+=`*Productos:*
`,n.forEach(s=>{e+=`• ${s.name}
`,e+=`  Talla: ${s.size} | Color: ${s.color}
`,e+=`  Precio: $${s.price.toLocaleString("es-CO")}

`}),e+=`*Total: $${t.toLocaleString("es-CO")}*`;const c=`https://wa.me/${i.public.whatsappNumber}?text=${encodeURIComponent(e)}`;return window.open(c,"_blank"),{success:!0}}});export{l as u};
