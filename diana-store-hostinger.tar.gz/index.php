<?php
// Simple index fallback for Hostinger
if (!file_exists($_SERVER['REQUEST_URI']) && $_SERVER['REQUEST_URI'] !== '/') {
    include_once 'index.html';
    exit();
}
?>